package com.four.jsonpostgres.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "json", name = "azs")
public class DataScheme {

    private String address;
    private Double latitude;
    private Double longtitude;
    @Id
    private String name;
    private String country;
    private String phone;
    private String region;

    public DataScheme(String address, Double latitude, Double longtitude, String name, String country, String phone, String region) {
        this.address = address;
        this.latitude = latitude;
        this.longtitude = longtitude;
        this.name = name;
        this.country = country;
        this.phone = phone;
        this.region = region;
    }

    public DataScheme() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Double longtitude) {
        this.longtitude = longtitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
}
