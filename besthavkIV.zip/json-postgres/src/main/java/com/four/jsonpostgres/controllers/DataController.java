package com.four.jsonpostgres.controllers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.four.jsonpostgres.entities.Config;
import com.four.jsonpostgres.entities.DataScheme;
import com.four.jsonpostgres.repositories.DataRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.*;
import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class DataController {

    // output logger
    private final static Logger logger = LoggerFactory.getLogger(DataController.class);

    // base files, change from config.json
    private static String jsonFileName = "azs.json";
    private static String csvFileName = "azs.csv";
    private static String xmlFileName = "azs.xml";

    // instance of an interface to save data to database
    private final DataRepository dataRepository;

    /**
     * Constructor
     * @param dataRepository - instance of interface
     */
    @Autowired
    public DataController(DataRepository dataRepository) {
        this.dataRepository = dataRepository;
    }

    /**
     * Writes text in JSON format to database
     * @param jsonText - provided text in JSON format
     */
    private void jsonToTable(String jsonText) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            List<DataScheme> dataSchemeList = objectMapper.readValue(jsonText, new TypeReference<List<DataScheme>>(){});
            dataRepository.saveAll(dataSchemeList);
            logger.info("saved");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Represents index page
     * runs function working with given in config filetype and filepath
     */
    @RequestMapping("")
    public void index() {
        URL url = this.getClass().getClassLoader().getResource("config.json");
        if (url != null) {
            File jsonFile = new File(url.getFile());
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                Config config = objectMapper.readValue(jsonFile, new TypeReference<Config>() {
                });
                switch (config.getFiletype()) {
                    case "csv":
                        csvFileName = config.getFilepath();
                        csv(config.getSeparator());
                        break;
                    case "json":
                        jsonFileName = config.getFilepath();
                        json();
                        break;
                    case "xml":
                        xmlFileName = config.getFilepath();
                        xml();
                        break;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            logger.warn("null config url!");
        }
    }

    /**
     * Reads data from xml and writes it to JSON format
     * then write it to database
     */
    @RequestMapping("xml")
    public void xml() {
        URL url = this.getClass().getClassLoader().getResource(xmlFileName);
        if (url != null) {
            File xmlFile = new File(url.getFile());
            XmlMapper xmlMapper = new XmlMapper();
            try {
                List<DataScheme> dataScheme = xmlMapper.readValue(xmlFile, new TypeReference<List<DataScheme>>(){});
                ObjectMapper mapper = new ObjectMapper();
                String jsonText = mapper.writeValueAsString(dataScheme);
                jsonToTable(jsonText);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            logger.warn("null url!");
        }
    }

    /**
     * Writes data from JSON file to database
     */
    @RequestMapping("json")
    public void json() {
        URL url = this.getClass().getClassLoader().getResource(jsonFileName);
        if (url != null) {
            File jsonFile = new File(url.getFile());
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                List<DataScheme> dataSchemeList = objectMapper.readValue(jsonFile, new TypeReference<List<DataScheme>>(){});
                dataRepository.saveAll(dataSchemeList);
                logger.info("saved");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            logger.warn("null url!");
        }
    }

    /**
     * Replaces system symbols in string with \ + symbol
     * @param s - given string
     * @return - correct string
     */
    private String clearString(String s) {
        return s.replace("\"", "'").replace("\\", "\\\\");
    }

    /**
     * Replaces given separator with one that can be read by JSON
     * @param del - given delimiter
     * @return - correct delimiter for JSON format
     */
    private String getDel(String del) {
        switch (del) {
            case "|":
                return "\\|";
            case "\\":
                return "\\\\";
            case "\"":
                return "\\\"";
            default:
                return del;
        }
    }

    /**
     * Reads data from csv with provided delimiter and writes it to JSON format
     * then write it to database
     * @param del - given delimiter
     */
    @RequestMapping(value = "csv/{del}")
    public void csv(@PathVariable String del) {
        URL url = this.getClass().getClassLoader().getResource(csvFileName);
        if (url != null) {
            File csvFile = new File(url.getFile());
            try (BufferedReader in = new BufferedReader(new FileReader(csvFile))) {
                String[] headers = in.readLine().split(getDel(del));
                List<String> azsList = in.lines().skip(1).map(line -> {
                    String[] x = line.split(getDel(del));
                    StringBuilder res = new StringBuilder("{");
                    for (int i = 0; i < x.length; ++i) {
                        try {
                            if (i == 1 || i == 2) {
                                res.append("\"").append(headers[i]).append("\" : ")
                                        .append(clearString(x[i])).append(",\n");
                                continue;
                            }
                            res.append("\"").append(headers[i]).append("\" : \"").append(clearString(x[i]));
                            if (i == x.length - 1) {
                                res.append("\"\n");
                            } else {
                                res.append("\",\n");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    return res + "},\n";
                }).collect(Collectors.toList());
                String jsonResult = "[" + String.join("", azsList) + "]";
                jsonResult = jsonResult.replace(",\n]", "\n]");
                jsonToTable(jsonResult);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            logger.warn("null url!");
        }
    }
}
