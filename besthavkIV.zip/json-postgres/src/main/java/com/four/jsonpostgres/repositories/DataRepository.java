package com.four.jsonpostgres.repositories;

import com.four.jsonpostgres.entities.DataScheme;
import org.springframework.data.repository.CrudRepository;

public interface DataRepository extends CrudRepository<DataScheme, Long> {
}
