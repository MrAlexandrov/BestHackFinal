package com.four.jsonpostgres.entities;

public class Config {
    private String filepath;
    private String filetype;
    private String separator;

    public Config() {
    }

    public Config(String filepath, String filetype, String separator) {
        this.filepath = filepath;
        this.filetype = filetype;
        this.separator = separator;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public String getSeparator() {
        return separator;
    }

    public void setSeparator(String separator) {
        this.separator = separator;
    }
}
