package com.four.jsonpostgres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonPostgresApplicationTests {

	@Test
	void contextLoads() {
	}

}
